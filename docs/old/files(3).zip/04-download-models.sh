#!/bin/bash

# =============================================================================
# 📦 STEP 4: DOWNLOAD AI MODELS
# =============================================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

print_step() { echo -e "\n${BLUE}==>${NC} ${GREEN}$1${NC}"; }
print_success() { echo -e "${GREEN}  ✓${NC} $1"; }
print_warning() { echo -e "${YELLOW}  ⚠${NC} $1"; }
print_info() { echo -e "${CYAN}  ℹ${NC} $1"; }

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  📦 Step 4: Download AI Models                                 ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Check Ollama
if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo "Error: Ollama is not running!"
    echo "Run: sudo systemctl start ollama"
    exit 1
fi

print_warning "This will download approximately 25GB of models"
print_warning "Estimated time: 30-60 minutes depending on internet speed"
echo ""

read -p "Continue? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Cancelled."
    exit 0
fi

echo ""

# -----------------------------------------------------------------------------
# Model 1: Qwen2.5-Coder-14B (Main coding model)
# -----------------------------------------------------------------------------
print_step "[1/5] Qwen2.5-Coder-14B (~9GB)"
print_info "Best overall coding model for 12GB VRAM"
ollama pull qwen2.5-coder:14b
print_success "Qwen2.5-Coder-14B downloaded"

# -----------------------------------------------------------------------------
# Model 2: Qwen2.5-Coder-7B (Fast model)
# -----------------------------------------------------------------------------
print_step "[2/5] Qwen2.5-Coder-7B (~5GB)"
print_info "Faster model for quick tasks & autocomplete"
ollama pull qwen2.5-coder:7b
print_success "Qwen2.5-Coder-7B downloaded"

# -----------------------------------------------------------------------------
# Model 3: DeepSeek-R1 (Reasoning)
# -----------------------------------------------------------------------------
print_step "[3/5] DeepSeek-R1:14B (~9GB)"
print_info "Best for complex reasoning & debugging"
ollama pull deepseek-r1:14b
print_success "DeepSeek-R1:14B downloaded"

# -----------------------------------------------------------------------------
# Model 4: Embedding model
# -----------------------------------------------------------------------------
print_step "[4/5] nomic-embed-text (~274MB)"
print_info "For RAG/document search"
ollama pull nomic-embed-text
print_success "nomic-embed-text downloaded"

# -----------------------------------------------------------------------------
# Model 5: Custom coding assistant
# -----------------------------------------------------------------------------
print_step "[5/5] Creating custom coding-assistant model"

cat > /tmp/Modelfile-coding << 'MODELFILE'
FROM qwen2.5-coder:14b

SYSTEM """Anda adalah asisten coding AI senior yang sangat ahli. Anda membantu developer dengan:

🔹 Menulis kode yang bersih, efisien, dan well-documented
🔹 Debugging dan troubleshooting dengan analisis detail
🔹 Code review untuk bugs, security, dan performance
🔹 Menjelaskan konsep kompleks dengan bahasa sederhana

Response Guidelines:
- Gunakan code blocks dengan syntax highlighting
- Struktur response dengan jelas
- Berikan penjelasan untuk setiap bagian penting
- Respons dalam bahasa yang sama dengan pertanyaan user (Indonesia/English)

Coding Standards:
- Selalu gunakan type hints untuk Python
- Tambahkan docstrings untuk functions
- Handle error dengan proper try/except
- Ikuti best practices dan design patterns"""

PARAMETER temperature 0.2
PARAMETER top_p 0.9
PARAMETER top_k 40
PARAMETER num_ctx 32768
PARAMETER repeat_penalty 1.1
PARAMETER stop "<|endoftext|>"
PARAMETER stop "<|im_end|>"
MODELFILE

ollama create coding-assistant -f /tmp/Modelfile-coding
rm /tmp/Modelfile-coding
print_success "Custom coding-assistant created"

# -----------------------------------------------------------------------------
# Summary
# -----------------------------------------------------------------------------
echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  ✅ Step 4 Complete - All Models Downloaded!                   ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "📦 Installed Models:"
ollama list
echo ""
echo "🧪 Quick Test:"
echo "   ollama run coding-assistant 'Write hello world in Python'"
echo ""
echo "Next: ./05-setup-webui.sh"
echo ""
