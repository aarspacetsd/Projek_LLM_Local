#!/bin/bash

# =============================================================================
# 🦙 STEP 3: OLLAMA WITH PROPER STORAGE CONFIGURATION
# =============================================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_step() { echo -e "\n${BLUE}==>${NC} ${GREEN}$1${NC}"; }
print_success() { echo -e "${GREEN}  ✓${NC} $1"; }
print_warning() { echo -e "${YELLOW}  ⚠${NC} $1"; }
print_info() { echo -e "${BLUE}  ℹ${NC} $1"; }

# Configuration - CHANGE THIS IF NEEDED
# Models will be stored here (should be on partition with most space)
OLLAMA_DATA="/var/lib/docker/ollama-data"

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  🦙 Step 3: Ollama Installation & Configuration                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# -----------------------------------------------------------------------------
# Show disk space
# -----------------------------------------------------------------------------
print_step "Checking disk space..."
echo ""
df -h | grep -E "Filesystem|/$|/var|/home|docker"
echo ""

print_info "Models will be stored in: $OLLAMA_DATA"
print_info "Make sure this partition has enough space (50GB+ recommended)"
echo ""

# -----------------------------------------------------------------------------
# Install Ollama
# -----------------------------------------------------------------------------
print_step "Installing Ollama..."

if command -v ollama &> /dev/null; then
    print_success "Ollama already installed"
else
    curl -fsSL https://ollama.com/install.sh | sh
    print_success "Ollama installed"
fi

# -----------------------------------------------------------------------------
# Configure Storage
# -----------------------------------------------------------------------------
print_step "Configuring Ollama storage..."

# Stop Ollama first
sudo systemctl stop ollama 2>/dev/null || true

# Create data directory
sudo mkdir -p "$OLLAMA_DATA"
sudo chown -R ollama:ollama "$OLLAMA_DATA"
sudo chmod -R 755 "$OLLAMA_DATA"

# Fix parent directory permission if using /var/lib/docker
if [[ "$OLLAMA_DATA" == /var/lib/docker/* ]]; then
    sudo chmod o+x /var/lib/docker
    print_info "Fixed /var/lib/docker permissions"
fi

# Create symlink in ollama home
sudo rm -rf /usr/share/ollama/.ollama 2>/dev/null || true
sudo ln -sf "$OLLAMA_DATA" /usr/share/ollama/.ollama
sudo chown -h ollama:ollama /usr/share/ollama/.ollama

# Create symlink in user home
rm -rf ~/.ollama 2>/dev/null || true
ln -sf "$OLLAMA_DATA" ~/.ollama

print_success "Storage configured at $OLLAMA_DATA"

# -----------------------------------------------------------------------------
# Configure Ollama Service
# -----------------------------------------------------------------------------
print_step "Configuring Ollama service..."

sudo mkdir -p /etc/systemd/system/ollama.service.d/

sudo tee /etc/systemd/system/ollama.service.d/override.conf > /dev/null << EOF
[Service]
Environment="OLLAMA_HOST=0.0.0.0"
Environment="OLLAMA_MODELS=$OLLAMA_DATA/models"
Environment="OLLAMA_NUM_PARALLEL=2"
Environment="OLLAMA_MAX_LOADED_MODELS=1"
Environment="OLLAMA_FLASH_ATTENTION=1"
Environment="OLLAMA_ORIGINS=*"
EOF

print_success "Service configured"

# -----------------------------------------------------------------------------
# Start Ollama
# -----------------------------------------------------------------------------
print_step "Starting Ollama..."

sudo systemctl daemon-reload
sudo systemctl enable ollama
sudo systemctl restart ollama

# Wait for Ollama
print_info "Waiting for Ollama to start..."
for i in {1..30}; do
    if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        print_success "Ollama is running!"
        break
    fi
    sleep 2
    echo -ne "\r  Waiting... ${i}s"
done
echo ""

# Verify
print_step "Verifying installation..."
curl -s http://localhost:11434/api/tags | jq . 2>/dev/null || echo "Ollama API responding"

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  ✅ Step 3 Complete!                                           ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "Ollama API: http://localhost:11434"
echo "Models dir: $OLLAMA_DATA/models"
echo ""
echo "Next: ./04-download-models.sh"
echo ""
